import random
import sys


def error1():
    statement_generator("Sorry, that is an invalid answer", "!")
    sys.exit(print("The program will now shut down. Please reboot."))


def statement_generator(statement, decoration):
    sides = decoration * 3
    statement = "{} {} {}".format(sides, statement, sides)
    top_bottom = decoration * len(statement)
    print(top_bottom)
    print(statement)
    print(top_bottom)
    print()
    return ""


statement_generator("Welcome to the Rock Paper Scissors minigame", "*")
print()

get_name = input("Please input your name. ")
print("Hello there " + get_name + "! Do you wish to view the instructions.")

instructions = input(
    "Type 'no' to proceed, and 'yes' if you wish to view the instructions. ")
print()

if (instructions != "yes") and (instructions != "Yes") and (
        instructions != "no") and (instructions != "No"):
    print(error1())

elif instructions == "yes" or instructions == "Yes":
    print()
    statement_generator("INSTRUCTIONS", "-")
    print()
    print("")
    print()
    valid = False
    while not valid:
      try:
        print("How many rounds do you wish to play?\n")
        print(
          "You can only play up to 10 rounds. For infinite mode, type Infinite"
        )
        mode = input
        if 0 < int(mode()) <= 10:
          print("You have chosen to play " + str(mode()) + " rounds.")
          print("Enter either Rock, Paper, or Scissors:\n")
          break
        elif str(mode()) == "Infinite" or str(mode()) == "infinite":
          print("Success")
        else:
          if int(mode()) <= 10 and int(mode()) >= 0 and str(
            mode()) != "Infinite" and str(mode()) != "infinite":
              print(error1())
              valid = True
      except ValueError:
        if str(mode()) == "Infinite" or str(mode()) == "infinite":
          print("You have chosen to play Infinite rounds. This means that the game will not end until you type: End")
          print("Enter either Rock, Paper, or Scissors:\n")
          valid = True
        else:
          print(error1())
          valid = True
          break

elif instructions == "no" or instructions == "No":
    valid = False
    while not valid:
        try:
            print("How many rounds do you wish to play?\n")
            print(
                "You can only play up to 10 rounds. For infinite mode, type Infinite"
            )
            mode = input
            if 0 < int(mode()) <= 10:
                print("You have chosen to play " + str(mode()) + " rounds.")
                print("Enter either Rock, Paper, or Scissors:\n")
                break
            elif str(mode()) == "Infinite" or str(mode()) == "infinite":
                print("Success")
            else:
                if int(mode()) <= 10 and int(mode()) >= 0 and str(
                        mode()) != "Infinite" and str(mode()) != "infinite":
                    print(error1())
                    valid = True
        except ValueError:
            if str(mode()) == "Infinite" or str(mode()) == "infinite":
              print("You have chosen to play Infinite rounds. This means that the game will not end until you type: End")
              print("Enter either Rock, Paper, or Scissors:\n")
              valid = True
            else:
              print(error1())
              valid = True
              break

STARTING_BALANCE = mode
balance = STARTING_BALANCE

### Recycled code below

rounds_played = 0
play_again = input("Press <enter> to play...").lower()
print()
while play_again == "":
    rounds_played += 1
    for item in range(0, 10):
        chosen_num = random.randint(1, 100)
        if 1 <= chosen_num <= 5:
            chosen = "!!! Unicorn !!!"
            balance += 4
        elif 6 <= chosen_num <= 36:
            chosen = "donkey"
            balance -= 1
        else:
            if chosen_num % 2 == 0:
                chosen = "horse"
            else:
                chosen = "zebra"
            balance -= 0.5
    item += 1
    print("*** Round #{} ***".format(rounds_played))
    print("You got a {}. Your balance is " "${:.2f}".format(chosen, balance))
    print()

    if rounds_played == mode:
        play_again = "xxx"
        print("Sorry, you have run out of money")
    else:
        play_again = input("Press <enter> to play again, or 'xxx' to quit ")

print()
print("Final balance: " "${:.2f}".format(balance))

sys.exit(print("The program will now self-destruct."))
