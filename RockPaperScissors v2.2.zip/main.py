import random
import sys


def error1():
    statement_generator("Sorry, that is an invalid answer", "!")
    sys.exit(print("The program will now shut down. Please reboot."))


def statement_generator(statement, decoration):
    sides = decoration * 3
    statement = "{} {} {}".format(sides, statement, sides)
    top_bottom = decoration * len(statement)
    print(top_bottom)
    print(statement)
    print(top_bottom)
    print()
    return ""


statement_generator("Welcome to the Rock Paper Scissors minigame", "*")
print()

get_name = input("Please input your name. ")
print("Hello there " + get_name + "! Do you wish to view the instructions.")

instructions = input(
    "Type 'no' to proceed, and 'yes' if you wish to view the instructions. ")
print()

if (instructions != "yes") and (instructions != "Yes") and (
        instructions != "no") and (instructions != "No"):
    print(error1())


elif instructions == "yes" or instructions == "Yes":
    print()
    statement_generator("INSTRUCTIONS", "-")
    print()
    print("")
    print()
    valid = False
    while not valid:
      try:
        print("How many rounds do you wish to play?\n")
        print(
          "You can only play up to 10 rounds. For infinite mode, type Infinite"
        )
        mode = input
        if 0 < int(mode()) <= 10:
          print("You have chosen to play " + str(mode()) + " rounds.")
          rps = input("Enter either Rock, Paper, or Scissors:\n")
          valid2 = True
          break
        elif str(mode()) == "Infinite" or str(mode()) == "infinite":
          print("Success")
        else:
          if 0 > int(mode()) >= 10 or str(mode()) != "Infinite" or str(mode()) != "infinite":
            print(error1())
            valid = True
      except ValueError:
        if str(mode()) == "Infinite" or str(mode()) == "infinite":
          print("You have chosen to play Infinite rounds. This means that the game will not end until you type: End")
          print("Enter either Rock, Paper, or Scissors:\n")
          valid = True
          valid2 = True
        else:
          print(error1())
          valid = True
          break

elif instructions == "no" or instructions == "No":
    valid = False
    while not valid:
        try:
            print("How many rounds do you wish to play?\n")
            print(
                "You can only play up to 10 rounds. For infinite mode, type Infinite"
            )
            mode = input
            if 0 < int(mode()) <= 10:
                print("You have chosen to play " + str(mode()) + " rounds.")
                rps = input("Enter either Rock, Paper, or Scissors:\n")
                valid2 = True
                break
            elif str(mode()) == "Infinite" or str(mode()) == "infinite":
                print("Success")
            else:
                if 0 > int(mode()) >= 10 or str(mode()) != "Infinite" or str(mode()) != "infinite":
                    print(error1())
                    valid = True
        except ValueError:
            if str(mode()) == "Infinite" or str(mode()) == "infinite":
              print("You have chosen to play Infinite rounds. This means that the game will not end until you type: End")
              print("Enter either Rock, Paper, or Scissors:\n")
              valid = True
              valid2 = True
            else:
              print(error1())
              valid = True
              break

valid2 = False
while not valid2:
  response = input(mode).lower()
  valid_list = response
  for item in valid_list:
    if response == item[0] or response == item:
      print(error1())
    else:
      print("You have chosen {}".format(response))
      break

rps_list = ["rock", "paper", "scissors", "xxx"]
user_choice = ""
while user_choice != "end":
  user_choice = choice_checker("Chose rock / paper "
  "scissors (r/p/s): ", rps_list,
  "Please choose from rock / "
  "paper / scissors "
  "(or end to quit)")
print("You chose {}".format(user_choice))