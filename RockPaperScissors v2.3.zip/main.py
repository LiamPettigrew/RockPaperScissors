import random
import sys


def error1():
    statement_generator("Sorry, that is an invalid answer", "!")
    sys.exit(print("The program will now shut down. Please reboot."))


def statement_generator(statement, decoration):
    sides = decoration * 3
    statement = "{} {} {}".format(sides, statement, sides)
    top_bottom = decoration * len(statement)
    print(top_bottom)
    print(statement)
    print(top_bottom)
    print()
    return ""


statement_generator("Welcome to the Rock Paper Scissors minigame", "*")
print()

get_name = input("Please input your name. ")
print("Hello there " + get_name + "! Do you wish to view the instructions.")

instructions = input(
    "Type 'no' to proceed, and 'yes' if you wish to view the instructions. ")
print()

if (instructions != "yes") and (instructions != "Yes") and (
        instructions != "no") and (instructions != "No"):
    print(error1())

elif instructions == "yes" or instructions == "Yes":
    print()
    statement_generator("INSTRUCTIONS", "-")
    print()
    print("")
    print()
    valid = False
    while not valid:
        try:
            print("How many rounds do you wish to play?\n")
            print(
                "You can only play up to 10 rounds. For infinite mode, type Infinite ")
            mode = input
            if 0 < int(mode()) <= 10:
                print("You have chosen to play " + str(mode()) + " rounds.\n")
                rps = input("Enter either Rock, Paper, or Scissors:\n")
                valid2 = True
                break
            elif str(mode()) == "Infinite" or str(mode()) == "infinite":
                print("Success")
            else:
                if 0 > int(mode()) >= 10 or str(mode()) != "Infinite" or str(
                        mode()) != "infinite":
                    print(error1())
                    valid = True
        except ValueError:
            if str(mode()) == "Infinite" or str(mode()) == "infinite":
                print(
                    "You have chosen to play Infinite rounds. This means that the game will not end until you type: End"
                )
                rps = input("Enter either Rock, Paper, or Scissors:\n")
                valid = True
                valid2 = True
            else:
                print(error1())
                valid = True
                break

elif instructions == "no" or instructions == "No":
    valid = False
    while not valid:
        try:
            print("How many rounds do you wish to play?")
            print(
                "You can only play up to 10 rounds. For infinite mode, type Infinite ")
            mode = input
            if 0 < int(mode()) <= 10:
                print("You have chosen to play " + str(mode()) + " rounds.\n")
                rps = input("Enter either Rock, Paper, or Scissors:\n")
                valid2 = True
                break
            elif str(mode()) == "Infinite" or str(mode()) == "infinite":
                print("Success")
            else:
                if 0 > int(mode()) >= 10 or str(mode()) != "Infinite" or str(
                        mode()) != "infinite":
                    print(error1())
                    valid = True
        except ValueError:
            if str(mode()) == "Infinite" or str(mode()) == "infinite":
                print(
                    "You have chosen to play Infinite rounds. This means that the game will not end until you type: End"
                )
                rps = input("Enter either Rock, Paper, or Scissors:\n")
                valid = True
                valid2 = True
            else:
                print(error1())
                valid = True
                break

rps_list = ["rock", "paper", "scissors", "end"]

if rps != "rock" and rps != "paper" and rps != "scissors" and rps != "end":
  print("This is an invalid answer (must be rock, paper or scissors).")
  print("NOTE: If you wish to end the game at any time, simply type; end")
  print()
  sys.exit(print("The program will now shut down. Please reboot."))

valid2 = False
while not valid2:
    response = input(rps).lower()
    for item in rps_list:
        if response == "end":
          print("test")
        else:
            print("You have chosen {}".format(response))

            computer_choice = random.randint(1, 3)
            if computer_choice == 1:
              print("rock")
              valid2 = False
            elif computer_choice == 2:
              print("paper")
              valid2 = False
            elif computer_choice == 3:
              print("scissors")
              valid2 = False

